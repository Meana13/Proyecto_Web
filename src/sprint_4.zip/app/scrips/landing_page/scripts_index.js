document.getElementById('button').addEventListener('click', function() {
    window.location.href = 'otra_pagina.html';
});